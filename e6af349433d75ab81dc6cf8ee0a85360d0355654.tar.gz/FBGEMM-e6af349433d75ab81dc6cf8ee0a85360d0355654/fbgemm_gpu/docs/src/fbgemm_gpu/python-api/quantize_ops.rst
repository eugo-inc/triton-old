Quantization Operators
======================

.. automodule:: fbgemm_gpu

.. _quantize-ops-stable-api:

Stable API
----------

.. autofunction:: torch.ops.fbgemm.FloatOrHalfToFusedNBitRowwiseQuantizedSBHalf

Other API
---------
