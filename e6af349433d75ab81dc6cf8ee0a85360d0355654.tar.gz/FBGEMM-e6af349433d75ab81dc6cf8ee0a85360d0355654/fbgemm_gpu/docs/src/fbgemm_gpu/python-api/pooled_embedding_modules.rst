Pooled Embedding Modules
========================

.. automodule:: fbgemm_gpu

.. _pooled-embedding-modules-stable-api:

Stable API
----------

.. autoclass:: fbgemm_gpu.permute_pooled_embedding_modules.PermutePooledEmbeddings
   :members: __call__

Other API
---------
