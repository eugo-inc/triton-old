Pooled Embedding Operators
==========================

.. automodule:: fbgemm_gpu

.. _pooled-embedding-operators-stable-api:

Stable API
----------

.. autofunction:: torch.ops.fbgemm.merge_pooled_embeddings

.. autofunction:: torch.ops.fbgemm.permute_pooled_embs

Other API
---------
