.. _fbgemm-gpu.dev.config.python:

Feature Gates (Python)
======================

.. automodule:: fbgemm_gpu

Stable API
----------

.. autoclass:: fbgemm_gpu.config.FeatureGateName

.. autoclass:: fbgemm_gpu.config.FeatureGate
