Jagged Tensor Operators
=======================

.. automodule:: fbgemm_gpu

.. _jagged-tensor-ops-stable-api:

Stable API
----------

.. autofunction:: torch.ops.fbgemm.jagged_to_padded_dense

Other API
---------

.. autofunction:: torch.ops.fbgemm.jagged_2d_to_dense

.. autofunction:: torch.ops.fbgemm.jagged_1d_to_dense

.. autofunction:: torch.ops.fbgemm.dense_to_jagged

.. autofunction:: torch.ops.fbgemm.jagged_dense_elementwise_add

.. autofunction:: torch.ops.fbgemm.jagged_dense_elementwise_add_jagged_output

.. autofunction:: torch.ops.fbgemm.jagged_dense_dense_elementwise_add_jagged_output

.. autofunction:: torch.ops.fbgemm.jagged_dense_elementwise_mul

.. autofunction:: torch.ops.fbgemm.batched_dense_vec_jagged_2d_mul

.. autofunction:: torch.ops.fbgemm.stacked_jagged_1d_to_dense

.. autofunction:: torch.ops.fbgemm.stacked_jagged_2d_to_dense
