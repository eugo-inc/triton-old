Table Batched Embedding Operators
=================================

.. doxygengroup:: table-batched-embed-cuda
   :content-only:
