.. _fbgemm-gpu.dev.config.cpp:

Feature Gates (C++)
===================

.. doxygengroup:: fbgemm-gpu-config
   :content-only:
