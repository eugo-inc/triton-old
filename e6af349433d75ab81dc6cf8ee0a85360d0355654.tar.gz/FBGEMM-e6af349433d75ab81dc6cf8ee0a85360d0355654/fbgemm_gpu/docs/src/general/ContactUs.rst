Contact Us
==========

GitHub
------

*  `GitHub Issues <https://github.com/pytorch/FBGEMM/issues>`__: Use this to
   file questions, issues, and feature requests concerning FBGEMM and/or
   FBGEMM_GPU.

*  `GitHub Discussions <https://github.com/pytorch/FBGEMM/discussions>`__: Use
   this to kick off longer discussions regarding FBGEMM and/or FBGEMM_GPU.

Slack
-----

For both FBGEMM and FBGEMM_GPU, feel free to reach out to us on the ``#fbgemm``
channel in `Pytorch Slack <https://bit.ly/ptslack>`__.
