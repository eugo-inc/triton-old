License
=======

Both FBGEMM and FBGEMM_GPU are licensed under the 3-clause BSD License:

.. literalinclude:: ../../../../LICENSE
  :language: text
