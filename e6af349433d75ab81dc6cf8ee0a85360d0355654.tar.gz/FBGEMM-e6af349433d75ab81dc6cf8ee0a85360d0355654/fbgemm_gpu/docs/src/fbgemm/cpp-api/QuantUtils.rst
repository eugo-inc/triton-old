Quantization Utilities
======================

Reference Implementation Methods
--------------------------------

.. doxygengroup:: fbgemm-quant-utils-generic
   :content-only:

AVX-2 Implementation Methods
----------------------------

.. doxygengroup:: fbgemm-quant-utils-avx2
   :content-only:

AVX-512 Implementation Methods
------------------------------

.. doxygengroup:: fbgemm-quant-utils-avx512
   :content-only:
