# FBGEMM_GPU Documentation

[![FBGEMM_GPU Docs CI](https://github.com/pytorch/FBGEMM/actions/workflows/fbgemm_gpu_docs.yml/badge.svg)](https://github.com/pytorch/FBGEMM/actions/workflows/fbgemm_gpu_docs.yml)

This is the repo for the FBGEMM_GPU project's documentation.  Please visit
[this page](src/general/DocsInstructions.rst) for more detailed information.
